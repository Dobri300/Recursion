package recursion.problems;

public class Problem4 {

	
	public static void printNumberDigits(int n)
	{
		if (n > 0) {		
			System.out.println(n%10);
			printNumberDigits(n/10);
		}

		
	}

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printNumberDigits(9876);
	}

}
