package recursion.problems;

public class Problem5 {
	
	public static void digitPrinterK(int n, int k, int counter)
	{
		if (counter == n)
		{
			System.out.println(k + " ");
		}
		if (counter<n) {	
			counter++;
			System.out.println(k + " ");
			digitPrinterK(n, k*10, counter);
		}
		else if(counter<n*2)
		{
			counter++;
			System.out.println(k + " ");
			digitPrinterK(n, k/10, counter);
			
		}
		
	}
	public static void digitPrinterK(int n)
	{
		digitPrinterK(n, 10, 1);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		digitPrinterK(5);
	}

}
