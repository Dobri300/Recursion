package recursion.problems;

import java.util.Stack;

public class Problem3 {

	public static void printNumberDigits(int n, Stack<Integer> digits)
	{
		if (n > 0) {		
			digits.push(n%10);
			n/=10;
			printNumberDigits(n, digits);
		}else if(digits.size() > 0)
		{
			System.out.print(digits.pop() + " ");
			printNumberDigits(n, digits);
		}
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> digits = new Stack<>();
			printNumberDigits(5678, digits);
	}

}
