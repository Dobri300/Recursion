package recursion.problems;

public class Problem1 {

	
	public static int sum(int position, int n, int sum)
	{
		if (position <= n) {
			return sum(position+1, n, sum+position);
			
		}else 
		{
			return sum;
		}
		
	}
	
	public static int sum(int n) {
		return sum(0, n, 0);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("The sum of the numbers from 0 to 15 is: " + sum(5));
		
	}

}
