package recursion.problems;

public class Problem2 {

	public static int sumOfDigits(int digit, int n, int sum)
	{
		digit = n%10;
		n /= 10;
		if (digit !=0) {
			
			return sumOfDigits(digit, n, sum+=digit);
			
		}else 
		{
			return sum;
		}
		
	}
	
	public static int sumOfDigits(int n)
	{
		return sumOfDigits(0, n, 0);
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("The number 111 has a total sum of its digits: "
		+ sumOfDigits(111));
		
	}

}
